package cl.speedfast.model;

public class PedidoEncomienda extends Pedido {

    public PedidoEncomienda(String idPedido, String direccionEntrega, double distanciaKm) {
        super(idPedido, direccionEntrega, distanciaKm);
    }

    @Override
    public int calcularTiempoEntrega() {
        double tiempo = 20 + (1.5 * distanciaKm);
        return (int) Math.round(tiempo);
    }
}
